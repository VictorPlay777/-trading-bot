def limit_order(self, symbol: str, side: str, qty: Decimal, price: float, reduce_only: bool = False):
        """Place a limit order (for TP/SL)"""
        try:
            params = {
                'category': 'linear',
                'symbol': symbol,
                'side': side,
                'orderType': 'Limit',
                'qty': str(qty),
                'price': str(price)
            }
            if reduce_only:
                params['reduceOnly'] = True
            
            result = self._request('POST', '/v5/order/create', params)
            if result.get('retCode') == 0:
                order_id = result.get('result', {}).get('orderId')
                self.logger.info(f'LIMIT ORDER PLACED: {symbol} {side} qty={qty} price={price} orderId={order_id}')
                return result
            else:
                self.logger.error(f'LIMIT ORDER FAILED: {symbol} {side} - {result}')
                return result
        except Exception as e:
            self.logger.error(f'LIMIT ORDER ERROR: {symbol} {side} - {e}')
            raise
