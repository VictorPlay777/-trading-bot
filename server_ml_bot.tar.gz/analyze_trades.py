#!/usr/bin/env python3
"""
Analyze trading performance from scanner logs
"""
import re
import sys
from collections import defaultdict

def analyze_log(log_file):
    trades = []
    current_positions = {}
    
    # Patterns
    open_pattern = r'>> OPENED (long|short) (\w+) qty=([\d.]+) value=([\d.]+)'
    close_pattern = r'>> CLOSED.*?(\w+).*?(profit|loss).*?PnL=([-\d.]+)'
    signal_pattern = r'(\w+): p_up=([\d.]+) p_dn=([\d.]+) signal=(long|short)'
    pnl_pattern = r'(\w+): PnL=([-\d.]+)'
    
    with open(log_file, 'r') as f:
        lines = f.readlines()
    
    for line in lines:
        # Parse OPENED
        match = re.search(open_pattern, line)
        if match:
            side, symbol, qty, value = match.groups()
            trades.append({
                'symbol': symbol,
                'side': side,
                'qty': float(qty),
                'value': float(value),
                'pnl': None,
                'p_up': None,
                'p_dn': None
            })
            current_positions[symbol] = trades[-1]
        
        # Parse signals with probabilities
        match = re.search(signal_pattern, line)
        if match:
            symbol, p_up, p_dn, signal = match.groups()
            if symbol in current_positions:
                current_positions[symbol]['p_up'] = float(p_up)
                current_positions[symbol]['p_dn'] = float(p_dn)
        
        # Parse closed positions with PnL
        match = re.search(r'Closed (\w+).*?profit.*?PnL=([-\d.]+)', line)
        if match:
            symbol, pnl = match.groups()
            if symbol in current_positions:
                current_positions[symbol]['pnl'] = float(pnl)
                del current_positions[symbol]
        
        match = re.search(r'Closed (\w+).*?SL.*?PnL=([-\d.]+)', line)
        if match:
            symbol, pnl = match.groups()
            if symbol in current_positions:
                current_positions[symbol]['pnl'] = float(pnl)
                del current_positions[symbol]
    
    # Statistics
    print("=" * 70)
    print("TRADING ANALYSIS REPORT")
    print("=" * 70)
    
    closed_trades = [t for t in trades if t['pnl'] is not None]
    open_trades = [t for t in trades if t['pnl'] is None]
    
    print(f"\n📊 OVERALL STATISTICS:")
    print(f"  Total trades: {len(trades)}")
    print(f"  Closed trades: {len(closed_trades)}")
    print(f"  Open positions: {len(open_trades)}")
    
    if closed_trades:
        winners = [t for t in closed_trades if t['pnl'] > 0]
        losers = [t for t in closed_trades if t['pnl'] <= 0]
        total_pnl = sum(t['pnl'] for t in closed_trades)
        
        print(f"\n💰 P&L SUMMARY:")
        print(f"  Winning trades: {len(winners)} ({len(winners)/len(closed_trades)*100:.1f}%)")
        print(f"  Losing trades: {len(losers)} ({len(losers)/len(closed_trades)*100:.1f}%)")
        print(f"  Total P&L: {total_pnl:.2f} USDT")
        print(f"  Average per trade: {total_pnl/len(closed_trades):.2f} USDT")
        
        if winners:
            avg_win = sum(t['pnl'] for t in winners) / len(winners)
            print(f"  Average win: +{avg_win:.2f} USDT")
        if losers:
            avg_loss = sum(t['pnl'] for t in losers) / len(losers)
            print(f"  Average loss: {avg_loss:.2f} USDT")
        
        # Probability analysis
        print(f"\n🎯 PROBABILITY ANALYSIS:")
        
        # For longs
        longs = [t for t in closed_trades if t['side'] == 'long']
        if longs:
            long_proba = [t for t in longs if t['p_up'] is not None]
            if long_proba:
                avg_proba_long = sum(t['p_up'] for t in long_proba) / len(long_proba)
                long_winners = [t for t in longs if t['pnl'] > 0]
                print(f"  Long positions: {len(longs)}")
                print(f"  Average p_up (entry): {avg_proba_long:.3f}")
                print(f"  Long win rate: {len(long_winners)/len(longs)*100:.1f}%")
        
        # For shorts
        shorts = [t for t in closed_trades if t['side'] == 'short']
        if shorts:
            short_proba = [t for t in shorts if t['p_dn'] is not None]
            if short_proba:
                avg_proba_short = sum(t['p_dn'] for t in short_proba) / len(short_proba)
                short_winners = [t for t in shorts if t['pnl'] > 0]
                print(f"  Short positions: {len(shorts)}")
                print(f"  Average p_dn (entry): {avg_proba_short:.3f}")
                print(f"  Short win rate: {len(short_winners)/len(shorts)*100:.1f}%")
        
        # Win rate by probability threshold
        print(f"\n📈 WIN RATE BY PROBABILITY:")
        
        high_conf = [t for t in closed_trades 
                     if (t['side'] == 'long' and t['p_up'] and t['p_up'] >= 0.70) or
                        (t['side'] == 'short' and t['p_dn'] and t['p_dn'] >= 0.70)]
        if high_conf:
            high_winners = [t for t in high_conf if t['pnl'] > 0]
            print(f"  High confidence (>=70%): {len(high_conf)} trades, {len(high_winners)/len(high_conf)*100:.1f}% win")
        
        med_conf = [t for t in closed_trades 
                    if (t['side'] == 'long' and t['p_up'] and 0.62 <= t['p_up'] < 0.70) or
                       (t['side'] == 'short' and t['p_dn'] and 0.62 <= t['p_dn'] < 0.70)]
        if med_conf:
            med_winners = [t for t in med_conf if t['pnl'] > 0]
            print(f"  Medium confidence (62-70%): {len(med_conf)} trades, {len(med_winners)/len(med_conf)*100:.1f}% win")
    
    # Current open positions
    if open_trades:
        print(f"\n🔓 CURRENT OPEN POSITIONS:")
        for t in open_trades[-10:]:  # Show last 10
            proba = t['p_up'] if t['side'] == 'long' else t['p_dn']
            proba_str = f" ({proba:.3f})" if proba else ""
            print(f"  {t['symbol']} {t['side']}{proba_str}: {t['value']:.0f} USDT")
    
    print("\n" + "=" * 70)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 analyze_trades.py ml_live_scanner.log")
        sys.exit(1)
    
    analyze_log(sys.argv[1])
