class ExitEngine:
    def compute_brackets(self, side: str, entry: float, atr: float, sl_atr_mult: float, tp1_r: float, tp2_r: float):
        risk = max(atr * sl_atr_mult, entry * 0.001)
        if side == "long":
            sl = entry - risk
            tp1 = entry + tp1_r * risk
            tp2 = entry + tp2_r * risk
        else:
            sl = entry + risk
            tp1 = entry - tp1_r * risk
            tp2 = entry - tp2_r * risk
        return {"sl": sl, "tp1": tp1, "tp2": tp2, "risk": risk}

